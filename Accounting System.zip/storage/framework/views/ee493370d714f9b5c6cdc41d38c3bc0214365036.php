
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <?php if(count($errors) >0): ?>
        <div class="col-md-12 col-lg-12">
          <div class="alert alert-danger alert-dismissible">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <?php echo e($error); ?>

                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <button type="button" class="close" data-dismiss="alert">&times;</button>
          </div>
        </div>
      <?php endif; ?>
      <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible">
          <ul>
            <li>
              <?php echo e(session()->get('success')); ?>

            </li>
          </ul>
          <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
      <?php endif; ?>
    <div class="col-lg-4 col-md-12" >
        <div class="card">
          <div class="card-header card-header-info">
              <strong>Change Password</strong>
          </div>
          <form action="<?php echo e(route('password')); ?>" method="post" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="admin_id" value="<?php echo e(Auth::user()->id); ?>">
            <div class="card-body card-block">
              <div class="row form-group">
                <div class="col col-md-3">
                  <label for="hf-password" class=" form-control-label" style="margin-top: 18%;">Password</label>
                </div>
                <div class="col-12 col-md-9">
                  <input name="password" type="password" id="hf-password" placeholder="Enter Password..." class="form-control">
                </div>
              </div>
            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">
                  <i class="fa fa-dot-circle-o"></i> Submit
              </button>
            </div>
          </form>
        </div>
    </div>
    
    <div class="col-lg-4 col-md-12" >
        <div class="card">
          <div class="card-header card-header-info" >
              <strong>Markting Bounce</strong>
          </div>
          <form action="<?php echo e(route('bounce')); ?>" method="post" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <div class="card-body card-block">
              <div class="row form-group">
                <div class="col col-md-3">
                  <label for="hf" class=" form-control-label" style="margin-top: 18%;">Target</label>
                </div>
                <div class="col-12 col-md-9">
                  <input type="number" id="hf" name="value" placeholder="Enter target..." class="form-control">
                </div>
              </div>
              <div class="row form-group">
                <div class="col col-md-3">
                  <label for="hf-password" class=" form-control-label" style="margin-top: 18%;">Precentage</label>
                </div>
                <div class="col-12 col-md-9">
                  <input type="text" id="hf-password" name="pre" placeholder="Enter Precentage" class="form-control">
                </div>
              </div>
            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info ">
                  <i class="fa fa-dot-circle-o"></i> Submit
              </button>
            </div>
          </form>
        </div>
    </div>

    <div class="col-lg-4 col-md-12" >
        <div class="card">
          <div class="card-header card-header-info">
              <strong>Change Password</strong>
          </div>
          <form action="<?php echo e(route('salary')); ?>" method="post" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="admin_id" value="<?php echo e(Auth::user()->id); ?>">
            <div class="card-body card-block">
              
              <select name="pla"  type="text" class="select2 form-control">
                <option></option>
                <?php $__currentLoopData = $pla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option style="color: black;" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

              <div class="row form-group">
                <div class="col col-md-3">
                  <label for="hf-password" class=" form-control-label" style="margin-top: 18%;">Salary</label>
                </div>
                <div class="col-12 col-md-9">
                  <input name="salary" type="text" id="hf-password" placeholder="Enter amount..." class="form-control">
                </div>
              </div>

            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">
                  <i class="fa fa-dot-circle-o"></i> Submit
              </button>
            </div>
          </form>
        </div>
    </div>
    </div>
    <div class="row">
      <div class="col-lg-6 col-md-12">
        <div class="card">
          <div class="card-header card-header-info">
            <h4 class="card-title ">Bounce Table</h4>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Value</th>
                    <th>Precentage</th>
                    <th>date</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if($bnc ??''): ?>
                    <?php $__currentLoopData = $bnc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td style="color: #fff;"><?php echo e($value2->id); ?></td>
                        <td style="color: #fff;"><?php echo e($value2->value); ?></td>
                        <td style="color: #fff;"><?php echo e($value2->procentage); ?>%</td>
                        <td style="color: #fff;"><?php echo e($value2->created_at); ?></td>
                        <td>
                          <a class="btn btn-danger" href="<?php echo e(route('bounce_delete',$value2->id ??'')); ?>">Delete</a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table> 
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-12">
        <div class="card">
          <div class="card-header card-header-info">
            <h4 class="card-title ">Salaries Table</h4>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Value</th>
                    <th>Player Name</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if($data ??''): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td style="color: #fff;"><?php echo e($value2->id); ?></td>
                        <td style="color: #fff;"><?php echo e($value2->value); ?></td>
                        <td style="color: #fff;"><?php echo e($value2->player->name ??''); ?></td>
                        <td>
                          <a class="btn btn-danger" href="<?php echo e(route('salary_delete',$value2->id ??'')); ?>">Delete</a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED\Desktop\Accounting System\resources\views/dashboard/settings/index.blade.php ENDPATH**/ ?>