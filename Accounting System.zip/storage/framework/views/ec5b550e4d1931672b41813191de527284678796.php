
<?php $__env->startSection('content'); ?>
<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                  <?php if(count($errors) >0): ?>
        <div class="col-md-12 col-lg-12">
          <div class="alert alert-danger alert-dismissible">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <?php echo e($error); ?>

                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <button type="button" class="close" data-dismiss="alert">&times;</button>
          </div>
        </div>
      <?php endif; ?>
      <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible">
          <ul>
            <li>
              <?php echo e(session()->get('success')); ?>

            </li>
          </ul>
          <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
      <?php endif; ?>
                  <div class="card-header card-header-tabs card-header-info">
                    <div class="nav-tabs-navigation">
                      <div class="nav-tabs-wrapper">
                        <span class="nav-tabs-title">Costs:</span>
                        <ul class="nav nav-tabs" data-tabs="tabs">
                          <li class="nav-item">
                            <a class="nav-link active" href="#profile" data-toggle="tab">
                              <i class="material-icons">bug_report</i> Costs
                              <div class="ripple-container"></div>
                            </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#messages" data-toggle="tab">
                              <i class="material-icons">code</i> Type
                              <div class="ripple-container"></div>
                            </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#settings" data-toggle="tab">
                              <i class="material-icons">cloud</i> Frequincies
                              <div class="ripple-container"></div>
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="card-body">
                    
                    <div class="tab-content">
                      
                      <div class="tab-pane active" id="profile">
                        <form method="post" >
                          <?php echo e(csrf_field()); ?>

                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Type</label>
                                <select name="type" type="text" class="form-control">
                                  <option></option>
                                  <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option style="color: black;" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                  
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Frequincy</label>
                                <select name="freq" type="text" class="form-control">
                                  <option></option>
                                  <?php $__currentLoopData = $freq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option style="color: black;" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                  
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Amount</label>
                                <input name="amount" type="text" class="form-control">
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <center>  <button type="submit" class="btn btn-warning" name="add">Save</button></center>
                          <div class="clearfix"></div>
                        </form>
                      </div>
                      
                      <div class="tab-pane" id="messages">
                        <form method="post" action="<?php echo e(route('type')); ?>">
                          <?php echo e(csrf_field()); ?>

                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">type Name</label>
                                <input name="type" type="text" class="form-control">
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <center>  <button type="submit" class="btn btn-warning" name="add">Save</button></center>
                          <div class="clearfix"></div>
                        </form>
                      </div>
                      
                      <div class="tab-pane" id="settings">
                        <form method="post" action="<?php echo e(route('freq')); ?>">
                          <?php echo e(csrf_field()); ?>

                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Frequincy </label>
                                <input name="freq" type="text" class="form-control">
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <center>  <button type="submit" class="btn btn-warning" name="add">Save</button></center>
                          <div class="clearfix"></div>
                        </form>
                      </div>

                    </div>
                  </div>
                </div>
            </div>
          </div>






          
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-info">
                  <h4 class="card-title ">Costs Table</h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>ID</th>
                        <th>Cost Amount</th>
                        <th>Type</th>
                        <th>Frequincy</th>
                        <th>Date</th>
                        <th>Action</th>
                      </thead>
                      <tbody>
                        <?php if($data ?? ''): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->amount); ?></td>
                            <td><?php echo e($row->type->name); ?></td>
                            <td><?php echo e($row->freq->name); ?></td>
                            <td><?php echo e($row->created_at); ?></td>
                            <td><a class="btn btn-danger" href="<?php echo e(route('cost_delete', $row->id)); ?>">Delete</a></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED\Desktop\Accounting System\resources\views/dashboard/costs/index.blade.php ENDPATH**/ ?>