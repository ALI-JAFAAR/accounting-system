
<?php $__env->startSection('content'); ?>
<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                  <?php if(count($errors) >0): ?>
        <div class="col-md-12 col-lg-12">
          <div class="alert alert-danger alert-dismissible">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <?php echo e($error); ?>

                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <button type="button" class="close" data-dismiss="alert">&times;</button>
          </div>
        </div>
      <?php endif; ?>
      <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible">
          <ul>
            <li>
              <?php echo e(session()->get('success')); ?>

            </li>
          </ul>
          <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
      <?php endif; ?>
                  <div class="card-header card-header-tabs card-header-info">
                    <div class="nav-tabs-navigation">
                      <div class="nav-tabs-wrapper">
                        <span class="nav-tabs-title">Project:</span>
                        <ul class="nav nav-tabs" data-tabs="tabs">
                          <li class="nav-item">
                            <a class="nav-link active" href="#profile" data-toggle="tab">
                              <i class="material-icons">bug_report</i> New Project
                              <div class="ripple-container"></div>
                            </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#messages" data-toggle="tab">
                              <i class="material-icons">code</i> Add Payment
                              <div class="ripple-container"></div>
                            </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#projects" data-toggle="tab">
                              <i class="material-icons">code</i> Projects
                              <div class="ripple-container"></div>
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div class="card-body">
                    
                    <div class="tab-content">
                      
                      <div class="tab-pane active" id="profile">
                        <form method="post" >
                          <br>
                          <br>
                          <?php echo e(csrf_field()); ?>

                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Project name</label>
                                <input name="name" type="text" class="form-control">
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Project Details</label>
                                <textarea name="details" type="text" class="form-control">
                                </textarea>
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Customer</label>
                                <select name="customer" type="text" class="form-control">
                                  <option></option>
                                  <?php $__currentLoopData = $cus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option style="color: black;" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Project Cost</label>
                                <input name="price" type="text" class="form-control">
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">First Payment</label>
                                <input name="payment" type="text" class="form-control">
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Programmer Name</label>
                                <select name="player[]" multiple type="text" class="select2 form-control">
                                  <option></option>
                                  <?php $__currentLoopData = $pla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option style="color: black;" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Department</label>
                                <select name="dept" type="text" class="form-control">
                                  <option></option>
                                  <?php $__currentLoopData = $dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option style="color: black;" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <center>  
                            <button type="submit" class="btn btn-warning" name="add">Save</button>
                          </center>
                          <div class="clearfix"></div>
                        </form>
                      </div>
                      
                      <div class="tab-pane" id="messages">
                        <form method="post" action="<?php echo e(route('payment')); ?>">
                          <?php echo e(csrf_field()); ?>

                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Projects</label>
                                <select name="pro_id" type="text" class="form-control">
                                  <option></option>
                                  <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option style="color: black;" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Value</label>
                                <input name="value" type="text" class="form-control">
                              </div>
                            </div>
                          </div>
                          <br>
                          <br>
                          <br>
                          <center>  <button type="submit" class="btn btn-warning" name="add">Save</button></center>
                          <div class="clearfix"></div>
                        </form>
                      </div>
                      
                      <div class="tab-pane" id="projects">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="card">
                              <div class="card-header card-header-info">
                                <h4 class="card-title ">Departments Table</h4>
                              </div>
                              <div class="card-body">
                                <div class="table-responsive">
                                  <table class="table">
                                    <thead class=" text-primary">
                                      <th>ID</th>
                                      <th>Project Name</th>
                                      <th>Project details</th>
                                      <th>Customer Name</th>
                                      <th>Projects Price</th>
                                      <th>Project Programmers</th>
                                      <th>Project Department </th>
                                      <th>Creation Date</th>
                                      <th>Action</th>
                                    </thead>
                                    <tbody>
                                      <?php if($pla ??''): ?>
                                      <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td><?php echo e($row->id); ?></td>
                                        <td><?php echo e($row->name); ?></td>
                                        <td><?php echo e($row->details); ?></td>
                                        <td><?php echo e($row->customer->name??''); ?></td>
                                        <td><?php echo e($row->price); ?></td>
                                        <td>
                                          <?php $__currentLoopData = $row->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($player->name); ?><br>,<?php echo e($player->department->name); ?><br>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($row->department->name ??''); ?></td>
                                        <td><?php echo e($row->created_at); ?></td>
                                        <td>
                                          <a class="btn btn-danger" href="<?php echo e(route('project-del',$row->id ??'')); ?>">
                                            Delete
                                          </a>
                                          <a class="btn btn-warning"  href="<?php echo e(route('pro-print',$row->id ??'')); ?>">
                                            Print Inovice
                                          </a>
                                        </td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div> 
                  </div>
                </div>
            </div>
          </div>

          
        </div>
      </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED\Desktop\Accounting System\resources\views/dashboard/projects/index.blade.php ENDPATH**/ ?>