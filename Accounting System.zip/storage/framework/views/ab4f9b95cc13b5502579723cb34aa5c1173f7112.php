
<?php $__env->startSection('content'); ?>
<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="card">
              <div class="card-body">
                <div class="chart-container" id="pdf">
                  <p style="color: white;">Report for this Month</p>
                  <div id="chartPie" style="width: 80%; margin: auto; height: 350px;background-color: white !important;">h1</div>
                  <div id="chart_area" id="Student Admission & Passout Details"></div>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            
            <div class="card">
              <div class="card-header card-header-info">
                <h4 class="card-title ">Reports Table</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <button type="button" name="view_chart" id="view_chart" class="btn btn-info btn-lg">View Data in Chart</button>
                  <table class="table" id="for_chart">
                    <thead>
                      <tr>
                        <th>Month</th>
                        <th>Total Revenue</th>
                        <th>Total Costs</th>
                        <th>Total Admin Expense</th>
                        <th>Salaries</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if($total ??''): ?>
                      <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value2['revenue'] <= 0): ?><?php $value2['revenue'] =0;?> <?php endif; ?>
                            <tr>
                              <td style="color: #fff;"><?php echo e(++$key); ?></td>
                              <td style="color: #fff;"><?php echo e($value2['revenue']); ?></td>
                              <td style="color: #fff;"><?php echo e($value2['costs']); ?></td>
                              <td style="color: #fff;"><?php echo e($value2['admin_cost']); ?></td>
                              <td style="color: #fff;"><?php echo e($value2['salary']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </tbody>
                  </table> 
                </div> 
              </div>
            </div>
          </div>

        </div>
      </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AHMED\Desktop\Accounting System\resources\views/dashboard/reports/index.blade.php ENDPATH**/ ?>